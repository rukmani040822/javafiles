package com.edu.job.service;

import java.util.List;

import com.edu.job.dao.User;

public interface UserService {

//public	User getUserById(Integer userid);

//public List<User> getAllUser();

public User saveUser(User user);

public List<User> getAllUser();

public User getUserByEmailPass(String useremail, String userpassword);

public List<User> deleteUserById(Integer id);

public User upateUserById(Integer id, User user);

}

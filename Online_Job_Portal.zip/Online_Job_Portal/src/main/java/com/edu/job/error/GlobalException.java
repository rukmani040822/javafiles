package com.edu.job.error;

public class GlobalException extends Exception {

	private static final long serialVersionUID = 1L;

	public GlobalException(String s) {
		super(s);
	}
	
}

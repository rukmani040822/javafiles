package com.edu.job.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.job.dao.User;
import com.edu.job.repository.UserRepository;
@Service
public class UserServiceImpl implements UserService {
    @Autowired
	private UserRepository userRepository;


	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub
		return userRepository.save(user);
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public User getUserByEmailPass(String useremail, String userpassword) {
		// TODO Auto-generated method stub
		User user =  userRepository.getUserByEmailPass(useremail,userpassword);
		return user;
	}

	@Override
	public List<User> deleteUserById(Integer id) {
		// TODO Auto-generated method stub
		 userRepository.deleteUserById(id);
		 return userRepository.findAll();
	}

	@Override
	public User upateUserById(Integer id, User user) {
		// TODO Auto-generated method stub
		User user2=userRepository.findById(id).get();
		user2.setUserfirstname(user.getUserfirstname());
		user2.setUserlastname(user.getUserlastname());
		user2.setUseremail(user.getUseremail());
		user2.setUsermobilenumber(user.getUsermobilenumber());
		user2.setUserpassword(user.getUserpassword());
		userRepository.save(user2);
		return user2;
	}

}

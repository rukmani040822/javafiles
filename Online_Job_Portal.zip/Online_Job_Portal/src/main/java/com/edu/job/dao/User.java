package com.edu.job.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private Integer id;
	
	@NotBlank(message="First name should not be null")
	@Pattern(message="Invalid First Name",regexp = "^[A-Za-z]+$")
	@Column(name="userfirstname",length=50,nullable=false)
	private String userfirstname;
	
	
	@NotBlank(message="Last name should not be null")
	@Pattern(message="Invalid Last Name",regexp = "^[A-Za-z]+$")
	@Column(name="userlastname",length=50)
    private String userlastname;
	
	
	@NotBlank(message="moblie number should not be empty")
	@Pattern(message="Invalid mobile number",regexp = "^[6-9]\\d{9}$")
	@Column(name = "usermobilenumber",unique = true, nullable = false)
	private String usermobilenumber;
	
	@NotBlank(message="Email should not be null")
	@Pattern(message = "Invalid Email",regexp="^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}")
	@Column(name = "useremail",unique = true, nullable = false)
	private String useremail;
	
	@Pattern(message = "Invalid Password" ,regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-+=()])(?=\\S+$).{8,20}$")
	@Column(name="userpassword",length=20,nullable = false)
	private String userpassword;

	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(
			@NotBlank(message = "First name should not be null") @Pattern(message = "Invalid First Name", regexp = "^[A-Za-z]+$") String userfirstname,
			@NotBlank(message = "Last name should not be null") @Pattern(message = "Invalid Last Name", regexp = "^[A-Za-z]+$") String userlastname,
			@NotBlank(message = "moblie number should not be empty") @Pattern(message = "Invalid mobile number", regexp = "^[6-9]\\d{9}$") String usermobilenumber,
			@NotBlank(message = "Email id should not be null") @Email(message = "Invalid Email", regexp = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+\\.[a-zA-Z.]{2,5}") String useremail,
			@Pattern(message = "Invalid Password", regexp = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&-+=()])(?=\\S+$).{8,20}$") String userpassword) {
		super();
		this.userfirstname = userfirstname;
		this.userlastname = userlastname;
		this.usermobilenumber = usermobilenumber;
		this.useremail = useremail;
		this.userpassword = userpassword;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUserfirstname() {
		return userfirstname;
	}

	public void setUserfirstname(String userfirstname) {
		this.userfirstname = userfirstname;
	}

	public String getUserlastname() {
		return userlastname;
	}

	public void setUserlastname(String userlastname) {
		this.userlastname = userlastname;
	}

	public String getUsermobilenumber() {
		return usermobilenumber;
	}

	public void setUsermobilenumber(String usermobilenumber) {
		this.usermobilenumber = usermobilenumber;
	}

	public String getUseremail() {
		return useremail;
	}

	public void setUseremail(String useremail) {
		this.useremail = useremail;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", userfirstname=" + userfirstname + ", userlastname=" + userlastname
				+ ", usermobilenumber=" + usermobilenumber + ", useremail=" + useremail + ", userpassword="
				+ userpassword + "]";
	}
	
	
	
	

}

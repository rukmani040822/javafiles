package com.edu.job.repository;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.edu.job.dao.User;

@Repository
public interface UserRepository extends JpaRepository<User, Integer>{
    @Query(value = "select * from user where useremail=?1 and userpassword=?2",nativeQuery = true)
	User getUserByEmailPass(String useremail, String userpassword);

	User findByUseremail(String useremail);
    @Transactional
    @Modifying
    @Query(value = "delete from user where id=?1",nativeQuery = true)
	void deleteUserById(Integer id);


}
